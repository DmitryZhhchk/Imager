﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

using Imager.Models;

namespace Imager.Controllers
{
    public class HomeController : Controller
    {

        private readonly IHostingEnvironment _env;

        
        private IImageProcessor _im;

        public HomeController(IHostingEnvironment env,IImageProcessor ip)
        {
            _env = env;
            _im = ip;
        }
       public IActionResult Index()
          {
            

              return View();
          }
       

        public string Process()
        {
            byte[] image = new byte[] { };

            string shape = Request.Form.FirstOrDefault(key => key.Key == "shape").Value.ToString();
            string option = Request.Form.FirstOrDefault(key => key.Key == "option").Value.ToString();
            string size = Request.Form.FirstOrDefault(key => key.Key == "size").Value.ToString();
       



         
            try
            {
                if (Request.Form.Files.Count > 0) //file has been loaded
                {

                    var file = Request.Form.Files[0];


                    if (file.Length > 0)
                    {
                        using (var stream = new MemoryStream())
                        {
                            file.CopyTo(stream);

                            _im.Load(stream);
                            using (var responsestream = new MemoryStream())
                            {

                                switch (shape)
                                {

                                    case "Pixel":
                                        {



                                            RecDrawType type = RecDrawType.BlackFrame;
                                            Cover cover = Cover.Full;
                                            switch (option)
                                            {
                                                case "Full&BlackFrame": type = RecDrawType.BlackFrame; cover = Cover.Full; break;
                                                case "Full&WhiteFrame": type = RecDrawType.WhiteFrame; cover = Cover.Full; break;
                                                case "Full&OnlyFill":   type = RecDrawType.OnlyFill; cover = Cover.Full;   break;
                                                case "Half&BlackFrame": type = RecDrawType.BlackFrame; cover = Cover.Half; break;
                                                case "Half&WhiteFrame": type = RecDrawType.WhiteFrame; cover = Cover.Half; break;
                                                case "Half&OnlyFill":   type = RecDrawType.OnlyFill; cover = Cover.Half; break;
                                                case "RandomFill":      type = RecDrawType.OnlyFill; cover = Cover.Random; break;
                                            }
                                            _im.Pixelate(responsestream, cover, Convert.ToInt16(size), type);
                                          
                                            break;
                                        }
                                    case "Circle":
                                        {
                                            CircleType type= CircleType.OnlyFill;

                                            switch (option)
                                            {
                                                case "OnlyFrame": type = CircleType.OnlyFrame; break;
                                                case "OnlyFill": type = CircleType.OnlyFill; break;
                                                case "RandomFill": type = CircleType.RandomFill; break;
                                                case "RandomFrame": type = CircleType.RandomFrame; break;
                                            }

                                            _im.Circlate(responsestream, Convert.ToInt16(size),type);


                                            break;
                                        }
                                }

                                image = responsestream.ToArray();
                                responsestream.Flush();
                            }

                            stream.Flush();

                        }

                    }

                }
                else
                       //use the same image
                {
                    _im.Reload();
                    using (var responsestream = new MemoryStream())
                    {

                        switch (shape)
                        {

                            case "Pixel":
                                {



                                    RecDrawType type = RecDrawType.BlackFrame;
                                    Cover cover = Cover.Full;
                                    switch (option)
                                    {
                                        case "Full&BlackFrame": type = RecDrawType.BlackFrame; cover = Cover.Full; break;
                                        case "Full&WhiteFrame": type = RecDrawType.WhiteFrame; cover = Cover.Full; break;
                                        case "Full&OnlyFill": type = RecDrawType.OnlyFill; cover = Cover.Full; break;
                                        case "Half&BlackFrame": type = RecDrawType.BlackFrame; cover = Cover.Half; break;
                                        case "Half&WhiteFrame": type = RecDrawType.WhiteFrame; cover = Cover.Half; break;
                                        case "Half&OnlyFill": type = RecDrawType.OnlyFill; cover = Cover.Half; break;
                                        case "RandomFill": type = RecDrawType.OnlyFill; cover = Cover.Random; break;
                                    }
                                    
                                    _im.Pixelate(responsestream, cover, Convert.ToInt16(size), type);

                                    break;
                                }
                            case "Circle":
                                {
                                    CircleType type = CircleType.OnlyFill;

                                    switch (option)
                                    {
                                        case "OnlyFrame": type = CircleType.OnlyFrame; break;
                                        case "OnlyFill": type = CircleType.OnlyFill; break;
                                        case "RandomFill": type = CircleType.RandomFill; break;
                                        case "RandomFrame": type = CircleType.RandomFrame; break;
                                    }

                                    _im.Circlate(responsestream, Convert.ToInt16(size), type);


                                    break;
                                }
                        }

                        image = responsestream.ToArray();
                        responsestream.Flush();
                    }

                }
                return Convert.ToBase64String(image);

            }
            catch (System.Exception ex)
            {
                return "Upload Failed: " + ex.Message;
            }
        }
     

  


    }
}
