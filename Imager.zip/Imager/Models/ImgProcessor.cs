﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Drawing.Processing;
using SixLabors.ImageSharp.Drawing;

using System.IO;
namespace Imager.Models
{


    public enum RecDrawType { BlackFrame, WhiteFrame, OnlyFill }

    public enum Cover { Full, Half, Random }
    public enum CircleType { OnlyFrame, OnlyFill, RandomFill,RandomFrame};

    public enum Frame { Black, White, None };
   
    public class ImgProcessor: IImageProcessor
    {

        protected Image<Rgba32> original_image { get; set; }
        protected Image<Rgba32> image { get; set; }

        public ImgProcessor() { }

        public  void Load(MemoryStream stream)
        {
            original_image = Image.Load<Rgba32>(stream.ToArray());

            image = new Image<Rgba32>(original_image.Width, original_image.Height);

            PointF[] my_rec = new PointF[4];
            my_rec[0].X = 0;
            my_rec[0].Y = 0;

            my_rec[1].X = image.Width;
            my_rec[1].Y = 0;

            my_rec[2].X = image.Width;
            my_rec[2].Y = image.Height;

            my_rec[3].X = 0;
            my_rec[3].Y = image.Height;

            image.Mutate(imageContext =>
            {
                imageContext.FillPolygon(new ShapeGraphicsOptions(), new SolidBrush(Color.White), my_rec);

            });

        }

        public  void Reload()
        {
           
            image = new Image<Rgba32>(original_image.Width, original_image.Height);

            PointF[] my_rec = new PointF[4];
            my_rec[0].X = 0;
            my_rec[0].Y = 0;

            my_rec[1].X = image.Width;
            my_rec[1].Y = 0;

            my_rec[2].X = image.Width;
            my_rec[2].Y = image.Height;

            my_rec[3].X = 0;
            my_rec[3].Y = image.Height;

            image.Mutate(imageContext =>
            {
                imageContext.FillPolygon(new ShapeGraphicsOptions(), new SolidBrush(Color.White), my_rec);

            });

        }


        //just to test
        public void Pink()
        {
            PointF[] my_rec = new PointF[4];
            my_rec[0].X = 0;
            my_rec[0].Y = 0;

            my_rec[1].X = image.Width;
            my_rec[1].Y = 0;

            my_rec[2].X = image.Width;
            my_rec[2].Y = image.Height;

            my_rec[3].X = 0;
            my_rec[3].Y = image.Height;
            image.Mutate(imageContext =>
            {
                  imageContext.FillPolygon(new ShapeGraphicsOptions(), new SolidBrush(Color.Pink), my_rec);

            });



        }

        public void ReloadOriginal()
        {

            image = original_image.Clone();
        }



        //everywhere we use RectangleF, but here Rectangle because we need to read pixels color
        //and it's coordinate is int
        public  Color GetBlockMeanColor(Rectangle rec)
        {

            List<byte> MaxR = new List<byte>();
            List<byte> MaxG = new List<byte>();
            List<byte> MaxB = new List<byte>();

            for (int x = rec.X; x < rec.Right; x++)
            {
                for (int y = rec.Y; y < rec.Bottom; y++)
                {
                    MaxR.Add(original_image[x, y].R);
                    MaxG.Add(original_image[x, y].G);
                    MaxB.Add(original_image[x, y].B);

                }
            }


            int sum = 0;
            foreach (byte b in MaxR)
            {
                sum = sum + b;
            }
            int Red = sum / MaxR.Count();

            sum = 0;
            foreach (byte b in MaxG)
            {
                sum = sum + b;
            }
            int Green = sum / MaxG.Count();

            sum = 0;
            foreach (byte b in MaxB)
            {
                sum = sum + b;
            }
            int Blue = sum / MaxB.Count();

            Color resultColor = Color.FromRgba((byte)Red, (byte)Green, (byte)Blue, 255);
            return resultColor;

        }


        public void AddText(string text, int size = 25)
        {

            image.Mutate(imageContext =>
            {

                var family = SixLabors.Fonts.SystemFonts.Collection.Families.FirstOrDefault();

                var font = SixLabors.Fonts.SystemFonts.CreateFont("Verdana", 20, SixLabors.Fonts.FontStyle.Regular);
                float x = image.Width / 2 - image.Width / 3;
                float y = image.Height / 2 / -image.Height / 3;

                var location = new PointF(x, y);

                imageContext.DrawText(text, font, Color.BlueViolet, location);
            });



        }


    
        public PointF[] RecFtoPointsF(RectangleF rec)
        {
           PointF[] my_rec = new PointF[4];
            my_rec[0].X = rec.X;
            my_rec[0].Y = rec.Y;

            my_rec[1].X = rec.X + rec.Width;
            my_rec[1].Y = rec.Y;

            my_rec[2].X = rec.X + rec.Width;
            my_rec[2].Y = rec.Y + rec.Height;

            my_rec[3].X = rec.X;
            my_rec[3].Y = rec.Y + rec.Height;

            return my_rec;

        }


        // the same pattern to fill area whether it's squares or circles
        // we make list of all coordinates and colors and draw it after
       

        public int FillWithPixels(float side)
        {
            int half_delimeter = 1;
            
            float cellside = side + 1;
            int hor_count = (image.Width / (int)side / half_delimeter);


            var recs = new List<(RectangleF rec, Color clr)>();
                         

            for (int x = 0; x < hor_count; x++)
                for (int y = 0; y < image.Height / side; y++)
                {
                    float coordX = x * side;
                    float coordY = y * side;

                    //in a case there is no place for whole cell
                    if (coordX + cellside > (float)(image.Width / half_delimeter)) cellside = side;

                    PointF top = new PointF(coordX, coordY);
                    RectangleF myrec_f = new RectangleF(coordX, coordY, cellside, cellside);

                    

                    int iX = (int)coordX;
                    int iY = (int)coordY;
                    int iSide = (int)side;

                    
                    if (iX + iSide > image.Width) iSide = image.Width - iX;

                    if (iY + iSide > image.Height) iSide = image.Height - iY;

                    if (iX < image.Width && iY < image.Height)
                    {
                        Rectangle myrec = new Rectangle(iX, iY, iSide, iSide);
                        Color clr = GetBlockMeanColor(myrec);
                        recs.Add((myrec_f, clr));

                    }

                }

            image.Mutate(imageContext =>
            {
            foreach (var re in recs)
            {
                    imageContext.FillPolygon(re.clr, RecFtoPointsF(re.rec));
            }

               
            });


            return hor_count;
        }


        public int FillWithHalfPixels(float side)
        {
            int half_delimeter=2;
           

            float cellside = side + 1;
            int hor_count = ((image.Width /2)/(int)side)+1;


            var recs = new List<(RectangleF rec, Color clr)>();


            for (int x = 0; x < hor_count; x++)
                for (int y = 0; y < image.Height / side; y++)
                {
                    float coordX = x * side;
                    float coordY = y * side;

                    //in a case there is no place for whole cell
                    if (coordX + cellside > (float)(image.Width / half_delimeter)) cellside = side;

                    PointF top = new PointF(coordX, coordY);
                    RectangleF myrec_f = new RectangleF(coordX, coordY, cellside, cellside);



                    int iX = (int)coordX;
                    int iY = (int)coordY;
                    int iSide = (int)side;


                    if (iX + iSide > image.Width) iSide = image.Width - iX;

                    if (iY + iSide > image.Height) iSide = image.Height - iY;

                    if (iX < image.Width && iY < image.Height)
                    {
                        Rectangle myrec = new Rectangle(iX, iY, iSide, iSide);
                        Color clr = GetBlockMeanColor(myrec);
                        recs.Add((myrec_f, clr));

                    }

                }

            image.Mutate(imageContext =>
            {
                foreach (var re in recs)
                {
                    imageContext.FillPolygon(re.clr, RecFtoPointsF(re.rec));
                }

               
            });


            return hor_count;
        }



        public void FillWithRandomPixels(int side)
        {
            
           int hor_count = image.Width / side;
           int ver_count = image.Height /side;

            var recs = new List<(RectangleF rec, Color clr)>();

           
                        Random rr = new Random();
                        int c = rr.Next(0, hor_count);
                        List<int> randomsOne = new List<int>();

                       //to get different number of filled cells in a column
                        for (int i = 0; i < ver_count; i++)
                        randomsOne.Add(rr.Next(ver_count));


                        for (int x = 0; x < hor_count; x++)
                        {
                            Random r = new Random();
                            List<int> randoms = new List<int>();

                          //to get different position for random cells  in a column
                            foreach (var ro in randomsOne)
                            {
                                int rrr = r.Next(ro);
                                if (!randoms.Contains(rrr))
                                {
                                    randoms.Add(rrr);
                                }
                            }
                            randoms.Sort();

                          


                            foreach (var rn in randoms)
                            {

                                float coordX = x * side;
                                float coordY = rn * side;
                                RectangleF myrec_f = new RectangleF(coordX, coordY, side, side);

                                int iX = (int)coordX;
                                int iY = (int)coordY;
                                int iSide = (int)side;

                                if (iX + iSide > image.Width) iSide = image.Width - iX;

                                if (iY + iSide > image.Height) iSide = image.Height - iY;

                                if (iX < image.Width && iY < image.Height)
                                {
                                    Rectangle myrec = new Rectangle(iX, iY, iSide, iSide);
                                    Color clr = GetBlockMeanColor(myrec);
                                 recs.Add((myrec_f, clr));
                       
                    }
                            }

                        }

            
            image.Mutate(imageContext =>
            {
                
                foreach (var re in recs)
                {
                    imageContext.FillPolygon(re.clr, RecFtoPointsF(re.rec));
                }
                
            });

            
        }

        //it's better to draw frames after drawing pixels- to not to draw overlapping sides
        public void FramePixels(int side, Color clr, bool half, int hor_count)
        {
            int half_delimeter = 1;
            if (half)   half_delimeter = 2;
            int width = image.Width / half_delimeter;

           

            hor_count = hor_count + 2;


            var points = new List<(PointF begin, PointF end)>();
                          
            
            PointF begin = new PointF();
            PointF end = new PointF();

            float coordX = 0; ;
            float coordY = 0; ;
           // vertical lines
            for (int x = 0; x < hor_count; x++)
            {
              
                coordX = x * side;

                if (coordX >= width) coordX = width - 1;

                if (coordX == 0) coordX = 0.5f;
                begin = new PointF(coordX, 0);
                end = new PointF(coordX, image.Height);
                points.Add((begin, end));
            }


            if (!half) coordX=image.Width;

           
            //hor lines
            for (int y = 0; y < (image.Height / side) +2; y++)
            {
                coordY = y * side ;

                if (coordY >= image.Height) coordY = image.Height - 0.5f;

                if (coordY == 0) coordY = 0.5f;


                begin = new PointF(0, coordY);
                end = new PointF(coordX, coordY);
                points.Add((begin, end));
            }
            
            image.Mutate(imageContext =>
            {
                Pen p = new Pen(clr,1);
                ShapeGraphicsOptions options = new ShapeGraphicsOptions();
                options.GraphicsOptions.Antialias = false;
                //opacity for pen
                options.GraphicsOptions.BlendPercentage = 0.3f;
               
                foreach (var tup in points)
                imageContext.DrawLines(options,p,tup.begin, tup.end);

            });
            }


        public void FrameHalfPixels(int side, Color clr, int hor_count)
        {
          
            hor_count = hor_count + 1;


            var points = new List<(PointF begin, PointF end)>();


            PointF begin = new PointF();
            PointF end = new PointF();

            float coordX = 0; ;
            float coordY = 0; ;
            // vertical lines
            for (int x = 0; x < hor_count; x++)
            {

                coordX = x * side;

                if (coordX == 0) coordX = 0.5f;
                begin = new PointF(coordX, 0);
                end = new PointF(coordX, image.Height);
                points.Add((begin, end));
            }


          

            for (int y = 0; y < (image.Height / side) + 2; y++)
            {
                coordY = y * side;

                if (coordY >= image.Height) coordY = image.Height - 0.5f;

                if (coordY == 0) coordY = 0.5f;


                begin = new PointF(0, coordY);
               
                end = new PointF(coordX, coordY);
                points.Add((begin, end));
            }

            image.Mutate(imageContext =>
            {
                Pen p = new Pen(clr, 1);
                ShapeGraphicsOptions options = new ShapeGraphicsOptions();
                options.GraphicsOptions.Antialias = false;
                options.GraphicsOptions.BlendPercentage = 0.3f;
                foreach (var tup in points)
                    imageContext.DrawLines(options, p, tup.begin, tup.end);

            });
        }



        public void FillWithFilledCircles(float side)
        {
            float rad = side / 2;
            float narrowrad = rad * 0.8f;
          
            var points = new List<(PointF center, Color clr)>();

                        for (int x = 0; x < image.Width / side; x++)
                            for (int y = 0; y < image.Height / side; y++)
                            {
                                float coordX = x * side;
                                float coordY = y * side;
                                PointF centeR = new PointF(coordX+rad, coordY+rad);
                                RectangleF myrec_f = new RectangleF(coordX, coordY, side, side);

                                int iX = (int)coordX;
                                int iY = (int)coordY;
                                int iSide = (int)side;

                                if (iX + iSide > image.Width) iSide = image.Width - iX;

                                if (iY + iSide > image.Height) iSide = image.Height - iY;

                                if (iX < image.Width && iY < image.Height)
                                {
                                    Rectangle myrec = new Rectangle(iX, iY, iSide, iSide);
                                    Color clr = GetBlockMeanColor(myrec);
                                    points.Add((centeR,clr));
                          
                                }

                            }

                image.Mutate(imageContext =>
                {
                    foreach (var tup in points)
                    {
                        EllipsePolygon circle = new EllipsePolygon(tup.center, narrowrad);
                        imageContext.Fill(tup.clr, circle);
                    }
                });







        }

        public void FillWithCircles(float side)
        {
            float rad = side / 2;
            float narrowrad = rad * 0.8f;

            var points = new List<(PointF center, Color clr)>();

            for (int x = 0; x < image.Width / side; x++)
                for (int y = 0; y < image.Height / side; y++)
                {
                    float coordX = x * side;
                    float coordY = y * side;
                    PointF centeR = new PointF(coordX + rad, coordY + rad);
                  

                    int iX = (int)coordX;
                    int iY = (int)coordY;
                    int iSide = (int)side;

                    if (iX + iSide > image.Width) iSide = image.Width - iX;

                    if (iY + iSide > image.Height) iSide = image.Height - iY;

                    if (iX < image.Width && iY < image.Height)
                    {
                        Rectangle myrec = new Rectangle(iX, iY, iSide, iSide);
                        Color clr = GetBlockMeanColor(myrec);
                        points.Add((centeR, clr));

                    }

                }
           
            image.Mutate(imageContext =>
            {

                
                ShapeGraphicsOptions options = new ShapeGraphicsOptions();
                options.GraphicsOptions.Antialias = false;

                foreach (var tup in points)
                {

                    Pen pen = new Pen(tup.clr, 1);
                    EllipsePolygon circle = new EllipsePolygon(tup.center, narrowrad);
                    imageContext.Draw(pen, circle);
                }
            });
        }

        public void FillWithRandomFilledCircles(float side)
        {
            float rad = side / 2;
            float narrowrad = rad * 0.8f;

            int hor_count = image.Width / (int)side;
            int ver_count = image.Height / (int)side;

            var points = new List<(PointF center, Color clr)>();





            Random rr = new Random();
            int c = rr.Next(0, hor_count);
            List<int> randomsOne = new List<int>();

            for (int i = 0; i < ver_count; i++)

                randomsOne.Add(rr.Next(ver_count));


            for (int x = 0; x < hor_count; x++)
            {
                Random r = new Random();
                List<int> randoms = new List<int>();


                foreach (var ro in randomsOne)
                {
                    int rrr = r.Next(ro);
                    if (!randoms.Contains(rrr))
                    {
                        randoms.Add(rrr);

                    }
                }
                randoms.Sort();




                foreach (var rn in randoms)
                {

                    float coordX = x * side;
                    float coordY = rn * side;
                    PointF centeR = new PointF(coordX + rad, coordY + rad);
                   

                    int iX = (int)coordX;
                    int iY = (int)coordY;
                    int iSide = (int)side;

                    if (iX + iSide > image.Width) iSide = image.Width - iX;

                    if (iY + iSide > image.Height) iSide = image.Height - iY;

                    if (iX < image.Width && iY < image.Height)
                    {
                        Rectangle myrec = new Rectangle(iX, iY, iSide, iSide);
                        Color clr = GetBlockMeanColor(myrec);
                        points.Add((centeR, clr));

                    }
                }

            }


            image.Mutate(imageContext =>
            {

                ShapeGraphicsOptions options = new ShapeGraphicsOptions();
                options.GraphicsOptions.Antialias = false;

                foreach (var tup in points)
                {
                    EllipsePolygon circle = new EllipsePolygon(tup.center, narrowrad);
                    imageContext.Fill(tup.clr, circle);
                    
                }
            });


        }

        public void FillWithRandomCircles(float side)
        {
            float rad = side / 2;
            float narrowrad = rad * 0.8f;

            int hor_count = image.Width / (int)side;
            int ver_count = image.Height / (int)side;

            var points = new List<(PointF center, Color clr)>();





            Random rr = new Random();
            int c = rr.Next(0, hor_count);
            List<int> randomsOne = new List<int>();

            for (int i = 0; i < ver_count; i++)

                randomsOne.Add(rr.Next(ver_count));


            for (int x = 0; x < hor_count; x++)
            {
                Random r = new Random();
                List<int> randoms = new List<int>();


                foreach (var ro in randomsOne)
                {
                    int rrr = r.Next(ro);
                    if (!randoms.Contains(rrr))
                    {
                        randoms.Add(rrr);

                    }
                }
                randoms.Sort();




                foreach (var rn in randoms)
                {

                    float coordX = x * side;
                    float coordY = rn * side;
                    PointF centeR = new PointF(coordX + rad, coordY + rad);
                    //RectangleF myrec_f = new RectangleF(coordX, coordY, side, side);

                    int iX = (int)coordX;
                    int iY = (int)coordY;
                    int iSide = (int)side;

                    if (iX + iSide > image.Width) iSide = image.Width - iX;

                    if (iY + iSide > image.Height) iSide = image.Height - iY;

                    if (iX < image.Width && iY < image.Height)
                    {
                        Rectangle myrec = new Rectangle(iX, iY, iSide, iSide);
                        Color clr = GetBlockMeanColor(myrec);
                        points.Add((centeR, clr));

                    }
                }

            }


            image.Mutate(imageContext =>
            {


                ShapeGraphicsOptions options = new ShapeGraphicsOptions();
                options.GraphicsOptions.Antialias = false;

                foreach (var tup in points)
                {

                    Pen pen = new Pen(tup.clr, 1);
                    EllipsePolygon circle = new EllipsePolygon(tup.center, narrowrad);
                    imageContext.Draw(pen, circle);
                }
            });


        }


        public void Pixelate(MemoryStream path_in, Cover cover, int delimeter, RecDrawType type)
        {
            using (image)
            {



                int size = 0; 
                int h_c = 0;
             
                switch (cover)
                {
                    case Cover.Full:
                        {
                            size =  (image.Width) / delimeter;

                            h_c =FillWithPixels(size); 

                          if (type == RecDrawType.BlackFrame)
                            {
                              
                                FramePixels(size, new Rgba32(0, 0, 0),false, h_c);
                            }

                            else
                            if (type == RecDrawType.WhiteFrame)
                            {
                           
                                FramePixels(size, new Rgba32(255, 255, 255), false,h_c);
                            }
                            

                            break;
                        }
                    case Cover.Half:
                        {
                            size = (image.Width/2) / delimeter;

                            ReloadOriginal();
                            h_c= FillWithHalfPixels(size); 


                            if (type == RecDrawType.BlackFrame)
                            {
                              
                                FrameHalfPixels(size, new Rgba32(0, 0, 0),h_c);
                            }

                            else
                           if (type == RecDrawType.WhiteFrame)
                            {
                              
                                FrameHalfPixels(size, new Rgba32(255, 255, 255),h_c);
                            }


                            break;
                        } 
                        
                    case Cover.Random:
                        {
                            size = (image.Width) / delimeter;
                            FillWithRandomPixels(size);
                            break;
                        }
                }
                
               

                image.Save(path_in, new JpegEncoder { Quality = 100 });
            }


        }


        public void Circlate(MemoryStream path_in,  int delimeter, CircleType type)
        {
            using (image)
            {

                float size = (float)image.Width / (float)delimeter;

                 switch (type)
                {
                 case CircleType.OnlyFill : FillWithFilledCircles(size);  break;

                 case CircleType.OnlyFrame: FillWithCircles(size);  break;

                 case CircleType.RandomFill: FillWithRandomFilledCircles(size);  break;

                 case CircleType.RandomFrame: FillWithRandomCircles(size); break;

                }
                image.Save(path_in, new JpegEncoder { Quality = 100 });
            }


        }




    }
}
                        

