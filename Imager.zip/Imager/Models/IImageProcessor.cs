﻿using System;
using System.Collections.Generic;
using System.IO;
using Imager.Models;

namespace Imager.Models
{
    public interface IImageProcessor
    {

        void Load(MemoryStream stream);
        void Reload();

        void Pixelate(MemoryStream path_in, Cover cover, int delimeter, RecDrawType type);
        void Circlate(MemoryStream path_in,int delimeter, CircleType type);
       

        

    }
}
